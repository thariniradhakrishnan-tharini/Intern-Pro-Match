import os
from sentence_transformers import SentenceTransformer

# Create a new folder in your project directory
os.environ["HF_HOME"] = "C:/project_folder/hf_cache"
os.makedirs("C:/project_folder/hf_cache", exist_ok=True)

# Load the model
model = SentenceTransformer('all-MiniLM-L6-v2')
