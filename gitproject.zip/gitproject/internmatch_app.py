import streamlit as st
import pdfplumber
import pandas as pd
import requests
import re
import firebase_admin
import spacy
import tempfile
import datetime
from firebase_admin import credentials, firestore
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import cosine_similarity
from internship_recommender import fetch_internships, fetch_crash_course
from difflib import SequenceMatcher
cred = credentials.Certificate("serviceAccountKey.json")
if not firebase_admin._apps:
    firebase_admin.initialize_app(cred)
db = firestore.client()
nlp = spacy.load("en_core_web_sm")
domain_examples = {
    "data science": "python machine learning pandas numpy sql deep learning nlp statistics data visualization scikit-learn seaborn matplotlib powerbi tableau data mining",
    "web development": "html css javascript react node.js express sql mongodb api bootstrap tailwindcss angular vue next.js frontend backend fullstack",
    "cloud computing": "aws docker kubernetes terraform azure linux ci cd cloud networking devops serverless lambda cloudformation ec2 s3 cloudwatch",
    "mobile development": "android kotlin swift react native flutter ios app design firebase xcode android studio ui ux cross-platform",
    "cyber security": "network security cryptography penetration testing firewalls linux forensic malware ethical hacking incident response encryption security analysis",
    "devops": "docker kubernetes jenkins ci cd terraform aws monitoring automation git ansible prometheus grafana pipelines",
    "artificial intelligence": "python deep learning tensorflow keras pytorch machine learning neural networks reinforcement learning nlp opencv computer vision",
    "blockchain": "solidity ethereum smart contracts web3 truffle metamask nft defi crypto consensus mining hyperledger distributed ledger",
    "internet of things": "iot arduino raspberrypi sensors actuators mqtt esp32 embedded systems cloud integration hardware interfacing",
    "ui ux design": "figma adobe xd sketch wireframe prototype user research usability design thinking interaction design user journey",
    "game development": "unity unreal-engine c# c++ game-design 3d-modeling blender physics animation rendering ai-pathfinding level-design",
    "robotics": "ros arduino python sensors actuators robot kinematics control systems navigation perception computer vision path planning",
    "database management": "sql mysql postgresql mongodb oracle database normalization indexing transactions query optimization nosql",
    "software testing": "unit-testing selenium junit pytest automation blackbox whitebox regression testing qa cucumber postman api-testing",
    "machine learning engineering": "python pandas numpy scikit-learn tensorflow keras deployment mlops docker flask fastapi aws model-serving"
}
@st.cache_resource
def train_domain_model(domain_examples):
    vectorizer = TfidfVectorizer()
    texts = list(domain_examples.values())
    X = vectorizer.fit_transform(texts)
    y = list(domain_examples.keys())
    model = LogisticRegression(max_iter=400)
    model.fit(X, y)
    return vectorizer, model

vectorizer, domain_model = train_domain_model(domain_examples)
TECH_KEYWORDS = {
    'python': 'python', 'java': 'java', 'c': 'c', 'c++': 'c++', 'c#': 'c#',
    'javascript': 'javascript', 'typescript': 'typescript', 'go': 'go', 'ruby': 'ruby',
    'php': 'php', 'swift': 'swift', 'kotlin': 'kotlin', 'r': 'r', 'matlab': 'matlab',
    'html': 'html', 'html5': 'html', 'css': 'css', 'css3': 'css', 'bootstrap': 'bootstrap',
    'tailwind': 'tailwind', 'react': 'react', 'react native': 'react', 'angular': 'angular',
    'vue': 'vue', 'node.js': 'node.js', 'express': 'express', 'django': 'django',
    'flask': 'flask', 'spring': 'spring', 'laravel': 'laravel', 'sql': 'sql',
    'mysql': 'mysql', 'postgresql': 'postgresql', 'mongodb': 'mongodb', 'redis': 'redis',
    'aws': 'aws', 'azure': 'azure', 'gcp': 'gcp', 'docker': 'docker', 'kubernetes': 'kubernetes',
    'jenkins': 'jenkins', 'tensorflow': 'tensorflow', 'keras': 'keras', 'pytorch': 'pytorch',
    'scikit-learn': 'scikit-learn', 'opencv': 'opencv', 'machine learning': 'machine learning',
    'deep learning': 'deep learning', 'nlp': 'nlp', 'jwt': 'jwt', 'rest api': 'rest api',
    'graphql': 'graphql', 'microservices': 'microservices', 'data analytics': 'data analytics'
}
def similarity(a, b):
    """Compute similarity ratio between two strings."""
    return SequenceMatcher(None, a, b).ratio() * 100

def extract_skills_from_resume(pdf_path):
    try:
        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text.lower() + " "

        text = re.sub(r'[^a-z0-9\s\+\#\.-]', ' ', text)
        doc = nlp(text)
        tokens = [token.text.strip() for token in doc if not token.is_stop and len(token.text) > 1]
        phrases = [chunk.text.strip() for chunk in doc.noun_chunks]
        all_terms = set(tokens + phrases)

        extracted_skills = set()
        for keyword, normalized in TECH_KEYWORDS.items():
            for term in all_terms:
                if similarity(keyword.lower(), term.lower()) > 85:
                    extracted_skills.add(normalized)

        return sorted(extracted_skills) if extracted_skills else []
    except Exception as e:
        st.error(f"⚠️ Error extracting skills: {e}")
        return []

def fetch_github_skills(username, token):
    try:
        headers = {"Authorization": f"token {token}"} if token else {}
        url = f"https://api.github.com/users/{username}/repos?per_page=100"
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code != 200:
            st.warning(f"GitHub fetch failed ({resp.status_code}).")
            return []
        repos = resp.json()
        langs = set()
        for r in repos:
            lang_data = requests.get(r.get("languages_url"), headers=headers, timeout=8).json()
            langs.update(lang.lower() for lang in lang_data.keys())
        return sorted(list(langs))
    except Exception as e:
        st.error(f"Error fetching GitHub data: {e}")
        return []

def predict_domain_from_skills(skill_tokens):
    if not skill_tokens:
        return "general", 0.0
    text = " ".join(skill_tokens)
    X = vectorizer.transform([text])
    pred = domain_model.predict(X)[0]
    prob = domain_model.predict_proba(X).max()
    return pred, float(prob)

def get_domain_skill_list(domain_name, top_k=15):
    domain_name = domain_name.lower()
    if domain_name in domain_examples:
        return domain_examples[domain_name].split()[:top_k]

    all_texts = list(domain_examples.values())
    keys = list(domain_examples.keys())
    vecs = vectorizer.transform(all_texts + [domain_name])
    sims = cosine_similarity(vecs[-1], vecs[:-1])[0]
    best_idx = sims.argmax()
    return domain_examples[keys[best_idx]].split()[:top_k]

def recommend_courses_for_skills(missing_skills, max_courses=3):
    if not missing_skills:
        return []
    return fetch_crash_course(missing_skills[:max_courses])

def save_user_data(user_id, user_info):
    try:
        db.collection("users").document(user_id).set(user_info)
        return True
    except Exception as e:
        st.error(f"Error saving to Firebase: {e}")
        return False

st.set_page_config(page_title="🎓 InternMatch Pro", layout="wide")
st.title("🎓 InternMatch Pro Dashboard")
st.markdown("**AI-based internship, course & skill matcher with GitHub verification.**")
st.divider()

col1, col2 = st.columns([1, 1])
with col1:
    st.subheader("📄 Upload Resume (PDF)")
    resume_file = st.file_uploader("Upload Resume", type=["pdf"])
    temp_resume_path = None
    resume_skills = []

    if resume_file:
        t = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        t.write(resume_file.getbuffer())
        t.flush()
        temp_resume_path = t.name
        resume_skills = extract_skills_from_resume(temp_resume_path)
        if resume_skills:
            st.success(f"Extracted relevant skills: {', '.join(resume_skills[:20])}...")
        else:
            st.warning("No skills detected in 'Technical Skills' or 'Area of Interest' sections.")

    st.subheader("🐙 GitHub Verification")
    github_username = st.text_input("GitHub Username")
    github_token = st.text_input("Personal Access Token (optional)", type="password")
    github_skills = []

    if github_username:
        with st.spinner("Fetching GitHub skills..."):
            github_skills = fetch_github_skills(github_username, github_token)
        if github_skills:
            st.success(f"Detected GitHub skills: {', '.join(github_skills)}")

    st.subheader("💡 Optional Domain Override")
    domain_input = st.text_input("Enter your preferred domain (optional)")

with col2:
    st.subheader("🧠 Dashboard Preview")
    user_email = st.text_input("Enter your Email ID")

    if st.button("🔍 Analyze & Save"):
        merged_skills = sorted(set(resume_skills + github_skills))
        if not merged_skills:
            st.error("No skills found from resume or GitHub!")
        else:
            domain, conf = predict_domain_from_skills(merged_skills) if not domain_input else (domain_input.lower(), 1.0)
            domain_skill_list = get_domain_skill_list(domain, top_k=20)
            common = sorted(set(merged_skills) & set(domain_skill_list))
            missing = sorted(set(domain_skill_list) - set(merged_skills))
            overlap_skills = sorted(set(resume_skills) & set(github_skills))
            if overlap_skills and not missing:
                st.success("✅ Verified! You have all key skills for this domain (cross-verified from Resume & GitHub).")
                st.markdown(f"**🧩 Verified Common Skills (Resume + GitHub):** {', '.join(overlap_skills)}")
                missing = ["None"]
                courses = []
            elif not missing:
                st.success("🌟 You already have all key skills for this domain!")
                missing = ["None"]
                courses = []
            else:
                courses = recommend_courses_for_skills(missing)

            internships = fetch_internships(domain.replace(" ", "-"), max_results=6)

            payload = {
                "email": user_email,
                "github": github_username,
                "skills": merged_skills,
                "domain": domain,
                "confidence": conf,
                "common": common,
                "missing": missing,
                "courses": courses,
                "internships": internships,
                "timestamp": datetime.datetime.utcnow()
            }
            save_user_data(user_email or github_username or "anonymous", payload)

            st.success(f"✅ Domain: {domain.title()} (Confidence: {conf:.2f})")
            st.markdown(f"**🧩 Common Skills:** {', '.join(common) if common else 'None'}")
            st.markdown(f"**⚡ Missing Skills:** {', '.join(missing)}")

            if courses:
                st.markdown("### 🎯 Recommended Courses")
                for i, c in enumerate(courses, 1):
                    st.markdown(f"**{i}. [{c['title']}]({c['link']})** — *{c['platform']}*")
            else:
                st.info("🎉 No courses needed — you're fully skilled for this domain!")

            st.markdown(" 💼 Internship Recommendations")
            if internships:
                st.markdown("""
                <style>
                table {width:100%;border-collapse:collapse;font-size:16px;border-radius:10px;overflow:hidden;}
                th {background-color:#262730;color:#00c3ff;padding:12px;text-align:center;}
                td {background-color:#1e1e1e;color:#e5e5e5;padding:10px;text-align:center;}
                tr:hover td {background-color:#333333;}
                a {color:#00c3ff;text-decoration:none;font-weight:600;}
                </style>
                """, unsafe_allow_html=True)

                df = pd.DataFrame(internships)
                df["Apply"] = df["link"].apply(lambda x: f'<a href="{x}" target="_blank">Apply Here</a>')
                st.markdown(df[["title", "company", "location", "Apply"]].to_html(escape=False, index=False), unsafe_allow_html=True)
            else:
                st.info("No internships found for this domain.")
