import requests
from bs4 import BeautifulSoup

def fetch_internships(domain="machine-learning", max_results=10):
    internships = []
    try:
        url = f"https://internshala.com/internships/{domain}-internship/"
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code != 200:
            return internships

        soup = BeautifulSoup(response.text, "html.parser")
        cards = soup.find_all("div", class_="individual_internship")[:max_results]

        for card in cards:
            title = card.find("h3", class_="job-internship-name")
            company = card.find("p", class_="company-name")
            link_tag = card.find("a", href=True)
            location_tag = card.find("a", class_="location_link")
            skills_tag = card.find("div", class_="internship_meta")

            internships.append({
                "title": title.text.strip() if title else "N/A",
                "company": company.text.strip() if company else "N/A",
                "location": location_tag.text.strip() if location_tag else "Remote / N/A",
                "skills": skills_tag.text.strip() if skills_tag else "N/A",
                "link": "https://internshala.com" + link_tag["href"] if link_tag and "/internship/" in link_tag["href"] else "N/A"
            })
    except Exception as e:
        print(f"Error fetching internships: {e}")
    return internships

def fetch_crash_course(skill_list=None, max_results=5):
    if not skill_list:
        return []
    return [{
        "title": f"Learn {skill.title()} — Free Online Course",
        "link": f"https://www.coursera.org/search?query={skill.lower().replace(' ', '+')}",
        "platform": "Coursera"
    } for skill in skill_list[:max_results]]
