import firebase_admin
from firebase_admin import credentials, firestore

try:
    cred = credentials.Certificate("serviceAccountKey.json")
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    print("✅ Firestore initialized successfully")

    # Test writing a document
    db.collection("test_users").document("test_user").set({
        "name": "Test User",
        "skills": ["Python", "Machine Learning"]
    })
    print("✅ Document written successfully")

    # Test reading the document
    doc = db.collection("test_users").document("test_user").get()
    if doc.exists:
        print("Document data:", doc.to_dict())
    else:
        print("No document found")

except Exception as e:
    print("❌ Error:", e)
